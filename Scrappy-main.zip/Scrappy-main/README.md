# SCRAPPY
Created a web app to promote garbage collection among Gen-Z's through gamification.</br>
• User can login with automated location fetching and see their dashboard for various stats.</br>
• User can host or take part in events which shows in everyone’s profile.</br>
• User can donate to the website through Stripe payment gateway.</br>
• Implemented the backend APIs using Node.js.</br>
• **Tech Stack**: Object Detection, AWS, TailwindCSS, ReactJS, NodeJS, Express, MongoDB

## Landing Page
![Landing](https://github.com/kushagra-gupta01/Scrappy/blob/main/img/LandingPage.png?raw=true)

## DashBoard
![Dashboard](https://github.com/kushagra-gupta01/Scrappy/blob/main/img/dashboard.png?raw=true)

## LeaderBoard
![leaderboard](https://github.com/kushagra-gupta01/Scrappy/blob/main/img/leaderboard.png?raw=true)

## Events Page
![Events Page](https://github.com/kushagra-gupta01/Scrappy/blob/main/img/EventsPage.png?raw=true)

## Donations
![Donations](https://github.com/kushagra-gupta01/Scrappy/blob/main/img/donationPage.png?raw=true)
